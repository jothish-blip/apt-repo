# Fish completion for felix
complete -c felix -f
complete -c felix -n "__fish_use_subcommand" -a "scan" -d "Perform web security audit"
complete -c felix -n "__fish_use_subcommand" -a "report" -d "Generate report from existing scan result"
complete -c felix -n "__fish_use_subcommand" -a "client" -d "Manage clients and organizations"
complete -c felix -n "__fish_use_subcommand" -a "assessment" -d "Manage authorized assessments"
complete -c felix -n "__fish_use_subcommand" -a "operator" -d "Launch operator console"
complete -c felix -n "__fish_use_subcommand" -a "config" -d "Manage operational settings"
complete -c felix -n "__fish_use_subcommand" -a "doctor" -d "Diagnose runtime health"
complete -c felix -n "__fish_use_subcommand" -a "version" -d "Show version information"
complete -c felix -n "__fish_use_subcommand" -a "update" -d "Check for or install updates"
complete -c felix -n "__fish_use_subcommand" -a "completion" -d "Generate shell completion"
complete -c felix -n "__fish_use_subcommand" -a "help" -d "Show help"
